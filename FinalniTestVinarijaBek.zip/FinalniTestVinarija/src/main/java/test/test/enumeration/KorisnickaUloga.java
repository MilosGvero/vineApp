package test.test.enumeration;

public enum KorisnickaUloga {
    ADMIN,
    KORISNIK
}
