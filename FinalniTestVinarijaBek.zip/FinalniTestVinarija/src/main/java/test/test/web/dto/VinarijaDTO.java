package test.test.web.dto;


public class VinarijaDTO {

	 private Long id;
	 
	 private String ime;
	 
	 private Integer godinaOsnivanja;

	public VinarijaDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public Integer getGodinaOsnivanja() {
		return godinaOsnivanja;
	}

	public void setGodinaOsnivanja(Integer godinaOsnivanja) {
		this.godinaOsnivanja = godinaOsnivanja;
	}
	 
	 
	
	
}
